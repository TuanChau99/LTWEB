package vn.iotstar.controllers.admin;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import vn.iotstar.daos.impl.CategoryDaoImpl;
import vn.iotstar.models.Category;

@WebServlet("/admin/category/add2")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, // 1MB
                 maxFileSize = 10 * 1024 * 1024,   // 10MB
                 maxRequestSize = 50 * 1024 * 1024 // 50MB
)
public class CategoryAddServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CategoryDaoImpl categoryDao;

    @Override
    public void init() throws ServletException {
        categoryDao = new CategoryDaoImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // chuyển hướng sang trang form thêm
        request.getRequestDispatcher("/views/admin/add-category.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setCharacterEncoding("UTF-8");

            String name = request.getParameter("name");

            // Xử lý upload icon
            Part filePart = request.getPart("icon");
            String fileName = extractFileName(filePart);

            String uploadPath = request.getServletContext().getRealPath("/uploads");
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }
            if (fileName != null && !fileName.isEmpty()) {
                filePart.write(uploadPath + File.separator + fileName);
            }

            // Tạo đối tượng Category
            Category cate = new Category();
            cate.setName(name);
            cate.setIcon(fileName);

            // Lưu DB
            categoryDao.insert(cate);

            // Sau khi thêm thành công → chuyển về list
            response.sendRedirect(request.getContextPath() + "/admin/category/list");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Thêm mới thất bại!");
            request.getRequestDispatcher("/views/admin/add-category.jsp").forward(request, response);
        }
    }

    // Lấy tên file upload
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        for (String s : contentDisp.split(";")) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return null;
    }
}
