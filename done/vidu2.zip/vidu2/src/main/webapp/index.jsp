<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
  <%@ taglib prefix="core1" uri="jakarta.tags.core" %>  
  
	<% response.sendRedirect(request.getContextPath() + "/login"); %>