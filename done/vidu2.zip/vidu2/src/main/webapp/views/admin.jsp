<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Trang quản trị Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white text-center">
            <h3>Chào mừng Admin!</h3>
        </div>
        <div class="card-body text-center">
            <p>Bạn đã đăng nhập với quyền <b>Quản trị viên</b>.</p>
            <a href="${pageContext.request.contextPath}/home" class="btn btn-success">Về trang Home</a>
            <a href="${pageContext.request.contextPath}/logout" class="btn btn-danger">Đăng xuất</a>
        </div>
    </div>
</div>

</body>
</html>
