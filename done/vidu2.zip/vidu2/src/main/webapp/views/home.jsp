<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Nhập thông tin</title>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<style>
    body {
        background-color: #f8f9fa;
    }
    .info-container {
        max-width: 450px;
        margin: 60px auto;
        padding: 25px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
    }
    .info-container h3 {
        text-align: center;
        margin-bottom: 20px;
        font-weight: 600;
    }
    .input-group-text {
        background-color: #f1f1f1;
    }
    .btn-primary {
        width: 100%;
    }
</style>
</head>
<body>

<div class="info-container">
    <h3>Nhập thông tin</h3>

    <p class="text-center text-success fw-bold">
        ${name}
    </p>

    <form action="${pageContext.request.contextPath}/home" method="post">
        <!-- Họ lót -->
        <div class="input-group mb-3">
            <span class="input-group-text"><i class="fa fa-user"></i></span>
            <input type="text" class="form-control" name="holot" placeholder="Họ và tên lót" required>
        </div>

        <!-- Tên -->
        <div class="input-group mb-3">
            <span class="input-group-text"><i class="fa fa-user"></i></span>
            <input type="text" class="form-control" name="ten" placeholder="Tên" required>
        </div>

        <!-- Submit -->
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-paper-plane"></i> Gửi thông tin
        </button>
    </form>
</div>

</body>
</html>
